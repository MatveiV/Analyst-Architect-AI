# AnalystGuru User Guide

> **AnalystGuru** — AI assistant for system analysts and solution architects.  
> Version: 1.0.0 | UI Languages: 🇷🇺 Russian / 🇬🇧 English

---

## Table of Contents

1. [Introduction and Roles](#1-introduction-and-roles)
2. [System Architecture (C4)](#2-system-architecture-c4)
3. [Signing In](#3-signing-in)
4. [Business Scenarios by Role](#4-business-scenarios-by-role)
5. [Working with Documents](#5-working-with-documents)
6. [AI Document Review](#6-ai-document-review)
7. [Architecture Studio](#7-architecture-studio)
8. [Knowledge Base (RAG)](#8-knowledge-base-rag)
9. [Memory Framework](#9-memory-framework)
10. [Audit Center](#10-audit-center)
11. [UML Workflow Diagrams](#11-uml-workflow-diagrams)

---

## 1. Introduction and Roles

### Who is this for?

AnalystGuru solves the problem of **expensive manual analysis** of technical specifications and architectural decisions. Without the system, an analyst spends 2–4 hours reviewing one specification; with AnalystGuru — 5–10 minutes.

### User Roles

Access to the system requires **mandatory username/password authentication** (JWT token, 8-hour lifetime). Every user is assigned one of three roles:

| Role | Description | Capabilities |
|------|-------------|--------------|
| **Analyst** (`analyst`) | Requirements specialist | Create and review documents, work with knowledge base, manage memory, view audit |
| **Architect** (`architect`) | Software architect | Everything analyst can do + AI provider settings, architecture recommendations, ADR generation |
| **Administrator** (`admin`) | System administrator | Full access + user management (create, roles, block, password reset) |

### Access Matrix

| Feature | Analyst | Architect | Administrator |
|---------|:---:|:---:|:---:|
| Username/password login | ✅ | ✅ | ✅ |
| Create documents | ✅ | ✅ | ✅ |
| AI review | ✅ | ✅ | ✅ |
| Architecture recommendations | ✅ | ✅ | ✅ |
| ADR generation | ✅ | ✅ | ✅ |
| Knowledge base / RAG | ✅ | ✅ | ✅ |
| View audit log | ✅ | ✅ | ✅ |
| AI provider settings | ❌ (403) | ✅ | ✅ |
| User management | ❌ (403) | ❌ (403) | ✅ |

> Restrictions are enforced **on the backend** (JWT + role check), not just hidden in the UI — calling a protected endpoint without the right role returns HTTP 403.

---

## 2. System Architecture (C4)

### C4 Level 1 — System Context

```mermaid
C4Context
    title AnalystGuru System Context

    Person(analyst, "Analyst", "Reviews specs, manages knowledge base")
    Person(architect, "Architect", "Designs architecture, creates ADRs")
    Person(admin, "Administrator", "Manages system and users")

    System(ag, "AnalystGuru", "AI assistant for system analysis and architecture")

    System_Ext(anthropic, "Anthropic Claude API", "LLM for AI analysis")
    System_Ext(openai, "OpenAI API", "Alternative LLM")
    System_Ext(proxyapi, "ProxyAPI", "OpenAI-compatible proxy")

    Rel(analyst, ag, "Logs in with username/password, uploads documents")
    Rel(architect, ag, "Generates architectural decisions")
    Rel(admin, ag, "Administers system and users")
    Rel(ag, anthropic, "Calls LLM API", "HTTPS/REST")
    Rel(ag, openai, "Calls LLM API (optional)", "HTTPS/REST")
    Rel(ag, proxyapi, "Calls via proxy (optional)", "HTTPS/REST")
```

### C4 Level 2 — Containers

```mermaid
C4Container
    title AnalystGuru Containers

    Person(user, "User")

    Container(frontend, "React SPA", "React 18 + TypeScript + Tailwind", "Dark-themed web interface with login screen")
    Container(backend, "FastAPI", "Python 3.11 + SQLAlchemy", "REST API, JWT auth, business logic, AI operations")
    ContainerDb(db, "SQLite / PostgreSQL", "SQLAlchemy async", "Users, documents, reviews, audit")

    System_Ext(llm, "LLM API", "Anthropic / OpenAI / ProxyAPI")

    Rel(user, frontend, "Uses browser", "HTTPS")
    Rel(frontend, backend, "REST API + JWT Bearer", "HTTP/JSON")
    Rel(backend, db, "Async queries", "SQLAlchemy")
    Rel(backend, llm, "AI calls", "HTTPS/REST")
```

### C4 Level 3 — Backend Components

```mermaid
C4Component
    title Backend Components

    Container_Boundary(api, "FastAPI Application") {
        Component(auth_r, "Auth Router", "JWT + bcrypt", "Login, profile, user management")
        Component(deps, "Auth Dependencies", "OAuth2PasswordBearer", "require_analyst / require_architect / require_admin")
        Component(docs_r, "Documents Router", "FastAPI (protected)", "Document CRUD, review trigger")
        Component(kb_r, "KB Router", "FastAPI (protected)", "Knowledge base, RAG search")
        Component(mem_r, "Memory Router", "FastAPI (protected)", "5-type memory framework")
        Component(audit_r, "Audit Router", "FastAPI (protected)", "Audit log viewer")
        Component(settings_r, "Settings Router", "FastAPI (architect+admin)", "AI provider settings")

        Component(ai_rev, "AI Reviewer", "Python", "Spec review, strict JSON output")
        Component(rag, "RAG Engine", "sentence-transformers", "Hybrid search (keyword + semantic)")
        Component(audit_svc, "Audit Service", "Python", "Logs all AI operations")
    }

    ComponentDb(db, "Database", "SQLite/PostgreSQL")

    Rel(docs_r, deps, "Validates JWT + role")
    Rel(settings_r, deps, "Requires architect|admin")
    Rel(docs_r, ai_rev, "Triggers review")
    Rel(kb_r, rag, "RAG search")
    Rel(ai_rev, audit_svc, "Logs operation")
    Rel(audit_svc, db, "Saves records")
```

---

## 3. Signing In

### Sign-in Steps

1. Open your browser and navigate to `http://localhost:3000`
2. The system shows the **login screen** (the app is inaccessible without authentication)
3. Enter your **username** and **password**
4. Click the **→ Sign in** button

On success, the backend issues a **JWT token** (valid for 8 hours), stored in the browser and automatically attached to every request. You will land on the main page — the documents list.

### Test Accounts

| Username | Password | Role |
|----------|----------|------|
| `admin` | `admin123` | Administrator |
| `analyst` | `analyst123` | Analyst |
| `architect` | `architect123` | Architect |

The login screen has quick-fill buttons for each of the three roles — handy for demos.

> ⚠️ Change default passwords before going to production!

### Signing Out

The **⎋** button next to your name in the sidebar removes the token from the browser and returns you to the login screen.

### Language Toggle

The 🇬🇧 EN / 🇷🇺 RU button is on the **login page** (top right) and in the **sidebar** (bottom section). Preference is saved in the browser independently of the auth session.

---

## 4. Business Scenarios by Role

### Scenario A: Analyst Reviews a Technical Specification

```
Step 0: Sign in — analyst / analyst123
Step 1: Analyst → [Documents] → [+ New Document]
Step 2: Fill in: title, type = TZ, project, text
Step 3: Click [🔍 Review]
Step 4: AI analyses the document (15–45 sec)
Step 5: Analyst reviews: summary, risks, client questions, acceptance criteria
Step 6: If needs_review=true → ⚠️ Manual check required
Step 7: Export review as JSON / CSV / DOCX
```

### Scenario B: Architect Creates an Architectural Decision

```
Step 0: Sign in — architect / architect123
Step 1: Architect → [Arch Studio]
Step 2: Select a document from the list
Step 3: Click [🏛 Recommend Architecture]
Step 4: Click [📋 Create ADR]
Step 5: Click [🔌 Create API Spec] → OpenAPI 3.1
Step 6: Click [🗺 Generate Diagrams] → C4, UML, ERD, Mermaid

Configure AI provider (architect/admin only):
Step 7: Architect → [⚙️ Settings]
Step 8: Select provider, enter API key, test connection
Step 9: Activate provider for the whole team
```

### Scenario C: Analyst Works with the Team Knowledge Base

```
Step 1: Analyst → [Knowledge Base] → [📚 Documents]
Step 2: Adds internal documents (rules, standards, FAQ)
Step 3: Switches to [💬 Ask Question] tab
Step 4: Types question in natural language
Step 5: System searches and forms an answer with citations
Step 6: If needs_review=true → knowledge base has no answer
```

### Scenario D: Administrator Manages the Team

```
Step 0: Sign in — admin / admin123
Step 1: Administrator → [👥 Users] → [+ Add User]
Step 2: Fill in: username, email, password, name, role
Step 3: New user can log in with those credentials
Step 4: As needed: change role (dropdown), reset password (🔑), block/unblock (🚫/✓)
```

---

## 5. Working with Documents

| Type | Code | Description |
|------|------|-------------|
| Technical Specification | `tz` | Classic development spec |
| BRD | `brd` | Business Requirements Document |
| User Story | `user_story` | User stories format |
| SRS | `srs` | Software Requirements Specification |
| KB Article | `kb_article` | Knowledge base article (indexed for RAG) |

Click **+ New Document**, fill in title/type/project/text (up to 30,000 chars), click **✓ Create**. The detail page has tabs: Text, Review, Architecture, ADR, API, Diagrams, Specifications.

---

## 6. AI Document Review

| Section | Description |
|---------|-------------|
| **Summary** | 2–6 sentences about the document |
| **Risks** | HIGH / MEDIUM / LOW |
| **Questions for client** | Resolve uncertainties |
| **Acceptance criteria** | Verifiable completion conditions |
| **Missing requirements** | What's missing to start development |
| **Confidence** | High / Medium / Low |

`needs_review = true` is set when: document too short (< 8 words), contradictory requirements, low AI confidence, or invalid JSON returned.

---

## 7. Architecture Studio

| Pattern | When to use |
|---------|-------------|
| Monolith | Small team, simple domain, MVP |
| Modular Monolith | Medium team, moderate complexity |
| Microservices | Large team, high load |
| Event-Driven | Loose coupling, async operations |
| CQRS | Different read/write requirements |
| Serverless | Unpredictable load, low budget |
| Hexagonal | Complex domain, testability |

---

## 8. Knowledge Base (RAG)

```
Documents → Split into chunks → Vectorisation
                                      ↓
Question → Keyword + Semantic search → Top-K chunks → LLM answer with citations
```

If no answer in knowledge base → `needs_review = true`, answer "Insufficient data".

---

## 9. Memory Framework

| Type | Purpose |
|------|---------|
| 🔷 Semantic | Concepts and standards |
| 📅 Episodic | Project lessons |
| ⚖️ Decisions | Architectural decisions |
| ⚠️ Risks | Typical risks |
| 📋 Requirements | Extracted requirements |

---

## 10. Audit Center

Every AI operation is logged with execution time, input/output, and status (✓ OK / ⚠ Needs Review / ✗ Error).

---

## 11. UML Workflow Diagrams

### Sequence Diagram: Authentication + AI Document Review

```mermaid
sequenceDiagram
    actor U as Analyst
    participant FE as Frontend
    participant API as FastAPI
    participant DB as Database
    participant LLM as LLM API

    U->>FE: Enters username/password
    FE->>API: POST /auth/login
    API->>DB: Verifies bcrypt hash
    API-->>FE: JWT access_token (8 hours)
    FE->>FE: Stores token in localStorage

    U->>FE: Creates document
    FE->>API: POST /documents\nAuthorization: Bearer <token>
    API->>API: Validates JWT + role (require_analyst)
    API->>DB: Saves document
    API-->>FE: {document_id}

    U->>FE: Triggers review
    FE->>API: POST /documents/{id}/review
    API->>DB: Reads text + memory context
    API->>LLM: Prompt + text
    LLM-->>API: Strict JSON response
    API->>API: Pydantic validation

    alt Validation successful
        API->>DB: Saves review (needs_review=false)
        API-->>FE: Review with data
    else JSON error / low confidence
        API->>DB: Saves review (needs_review=true)
        API-->>FE: Review with ⚠ flag
    end
```

### Activity Diagram: Analyst Workflow

```mermaid
flowchart TD
    A([Start]) --> B[Sign in\nusername/password]
    B --> C{Document\nalready created?}
    C -->|No| D[Create document]
    C -->|Yes| E[Open document]
    D --> E
    E --> F[Run AI review]
    F --> G{needs_review?}
    G -->|true| H[⚠ Read client\nquestions]
    G -->|false| I[Study review]
    H --> J[Clarify requirements]
    J --> D
    I --> K{Architecture\nneeded?}
    K -->|Yes| L[Arch Studio:\nrecommendations + ADR]
    K -->|No| M[Export review]
    L --> M
    M --> N([End])
```

### State Diagram: Review Lifecycle

```mermaid
stateDiagram-v2
    [*] --> Created : Document uploaded
    Created --> Processing : Review triggered
    Processing --> Ready : needs_review=false
    Processing --> NeedsReview : needs_review=true
    NeedsReview --> Created : Analyst clarified requirements
    Ready --> Exported : Downloaded JSON/CSV/DOCX
    Exported --> [*]
```

### Class Diagram: Domain Model (including users)

```mermaid
classDiagram
    class User {
        +String id
        +String username
        +String email
        +String hashed_password
        +String role
        +Boolean is_active
        +login()
        +hasPermission(permission)
    }

    class Document {
        +String id
        +String title
        +String text
        +String doc_type
    }

    class Review {
        +String id
        +String document_id
        +String review_json
        +Boolean needs_review
        +String confidence
    }

    class AuditRun {
        +String id
        +String action
        +String status
        +Integer duration_ms
    }

    Document "1" --> "*" Review : has
    AuditRun "*" --> "1" User : performed by
```
