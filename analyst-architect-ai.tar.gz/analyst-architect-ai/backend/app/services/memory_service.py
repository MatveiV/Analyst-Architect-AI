"""
Memory Framework — хранение и поиск по 5 типам памяти:
semantic | episodic | decision | risk | requirement
"""
import json
import re
import uuid
from datetime import datetime
from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc

from app.models.memory_item import MemoryItem
from app.schemas import MemoryItemOut


async def store_memory(
    db: AsyncSession,
    memory_type: str,
    content: str,
    tags: List[str],
    project_name: Optional[str] = None,
) -> MemoryItem:
    item = MemoryItem(
        id=str(uuid.uuid4()),
        created_at=datetime.utcnow(),
        memory_type=memory_type,
        content=content,
        tags=json.dumps(tags, ensure_ascii=False),
        project_name=project_name,
    )
    db.add(item)
    await db.commit()
    return item


def _text_similarity(query: str, text: str) -> float:
    """Simple keyword-based relevance."""
    q_words = set(re.findall(r"\w+", query.lower()))
    t_words = set(re.findall(r"\w+", text.lower()))
    if not q_words:
        return 0.0
    return len(q_words & t_words) / len(q_words)


async def search_memory(
    db: AsyncSession,
    query: str,
    memory_type: Optional[str] = None,
    project_name: Optional[str] = None,
    limit: int = 10,
) -> List[MemoryItem]:
    q = select(MemoryItem)
    if memory_type:
        q = q.where(MemoryItem.memory_type == memory_type)
    if project_name:
        q = q.where(MemoryItem.project_name == project_name)
    result = await db.execute(q)
    items = result.scalars().all()

    # Score by relevance
    scored = [(item, _text_similarity(query, item.content)) for item in items]
    scored.sort(key=lambda x: x[1], reverse=True)

    # Update relevance scores
    top = scored[:limit]
    for item, score in top:
        item.relevance_score = score

    return [item for item, _ in top]


async def get_recent_memory(
    db: AsyncSession,
    memory_type: Optional[str] = None,
    limit: int = 20,
) -> List[MemoryItem]:
    q = select(MemoryItem).order_by(desc(MemoryItem.created_at))
    if memory_type:
        q = q.where(MemoryItem.memory_type == memory_type)
    q = q.limit(limit)
    result = await db.execute(q)
    return result.scalars().all()


async def get_memory_context(
    db: AsyncSession,
    project_name: Optional[str] = None,
) -> dict:
    """Return memory context summary for LLM prompts."""
    risks_q = select(MemoryItem).where(MemoryItem.memory_type == "risk").limit(5)
    lessons_q = select(MemoryItem).where(MemoryItem.memory_type == "episodic").limit(5)
    decisions_q = select(MemoryItem).where(MemoryItem.memory_type == "decision").limit(5)

    if project_name:
        risks_q = risks_q.where(MemoryItem.project_name == project_name)
        lessons_q = lessons_q.where(MemoryItem.project_name == project_name)
        decisions_q = decisions_q.where(MemoryItem.project_name == project_name)

    risks = (await db.execute(risks_q)).scalars().all()
    lessons = (await db.execute(lessons_q)).scalars().all()
    decisions = (await db.execute(decisions_q)).scalars().all()

    return {
        "memory_risks": "; ".join(r.content[:100] for r in risks),
        "memory_lessons": "; ".join(l.content[:100] for l in lessons),
        "memory_decisions": "; ".join(d.content[:100] for d in decisions),
    }
