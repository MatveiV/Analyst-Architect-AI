"""
Export Service — экспорт данных в JSON, CSV, DOCX.
"""
import csv
import io
import json
from typing import Any


def export_review_json(review_data: dict) -> bytes:
    return json.dumps(review_data, ensure_ascii=False, indent=2).encode("utf-8")


def export_review_csv(review_data: dict) -> bytes:
    output = io.StringIO()
    writer = csv.writer(output)

    writer.writerow(["Поле", "Значение"])
    writer.writerow(["summary", review_data.get("summary", "")])
    writer.writerow(["confidence", review_data.get("confidence", "")])
    writer.writerow(["needs_review", review_data.get("needs_review", "")])

    writer.writerow([])
    writer.writerow(["Риски", ""])
    writer.writerow(["severity", "description"])
    for risk in review_data.get("risks", []):
        writer.writerow([risk.get("severity", ""), risk.get("description", "")])

    writer.writerow([])
    writer.writerow(["Вопросы заказчику", ""])
    for q in review_data.get("questions_to_client", []):
        writer.writerow([q])

    writer.writerow([])
    writer.writerow(["Критерии приёмки", ""])
    for c in review_data.get("acceptance_criteria", []):
        writer.writerow([c])

    return output.getvalue().encode("utf-8-sig")  # BOM for Excel


def export_document_docx(title: str, content: dict) -> bytes:
    """Export document to DOCX format."""
    try:
        from docx import Document
        from docx.shared import Pt, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        doc = Document()

        # Title
        title_para = doc.add_heading(title, level=1)

        def add_section(heading: str, items: list, bullet: bool = True):
            if not items:
                return
            doc.add_heading(heading, level=2)
            if bullet:
                for item in items:
                    doc.add_paragraph(str(item), style="List Bullet")
            else:
                for item in items:
                    doc.add_paragraph(str(item))

        # Summary
        if "summary" in content:
            doc.add_heading("Резюме", level=2)
            doc.add_paragraph(content["summary"])

        # Risks
        risks = content.get("risks", [])
        if risks:
            doc.add_heading("Риски", level=2)
            for risk in risks:
                if isinstance(risk, dict):
                    p = doc.add_paragraph(style="List Bullet")
                    sev = risk.get("severity", "")
                    p.add_run(f"[{sev.upper()}] ").bold = True
                    p.add_run(risk.get("description", ""))

        add_section("Отсутствующие требования", content.get("missing_requirements", []))
        add_section("Вопросы заказчику", content.get("questions_to_client", []))
        add_section("Критерии приёмки", content.get("acceptance_criteria", []))
        add_section("Архитектурные риски", content.get("architecture_risks", []))

        # Metadata
        conf = content.get("confidence", "")
        needs = content.get("needs_review", False)
        doc.add_heading("Метаданные", level=2)
        doc.add_paragraph(f"Уверенность: {conf}")
        doc.add_paragraph(f"Требует проверки: {'Да ⚠️' if needs else 'Нет'}")

        buf = io.BytesIO()
        doc.save(buf)
        return buf.getvalue()
    except ImportError:
        # Fallback to plain text if python-docx not available
        text = f"{title}\n{'='*len(title)}\n\n"
        text += json.dumps(content, ensure_ascii=False, indent=2)
        return text.encode("utf-8")
