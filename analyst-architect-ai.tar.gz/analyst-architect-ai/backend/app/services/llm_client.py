"""
Unified LLM client — Anthropic Claude, OpenAI GPT, ProxyAPI.

Priority for runtime config:
  1. DB-stored ProviderSettings (if api_key present)
  2. app.config.settings (from .env)
"""
import json
from app.config import settings


async def _load_active_config() -> dict:
    """
    Try to load active provider config from DB.
    Returns dict with: provider, api_key, model, base_url, temperature, max_tokens.
    Falls back to env-based settings if DB is empty / not reachable.
    """
    try:
        from app.database import AsyncSessionLocal
        from app.models.provider_settings import ProviderSettings
        from sqlalchemy import select

        async with AsyncSessionLocal() as db:
            res = await db.execute(
                select(ProviderSettings).where(ProviderSettings.is_active == "true")
            )
            row = res.scalar_one_or_none()
            if row and row.api_key:
                return {
                    "provider": row.provider,
                    "api_key": row.api_key,
                    "model": row.model,
                    "base_url": row.base_url or "",
                    "temperature": float(row.temperature or "0.2"),
                    "max_tokens": int(row.max_tokens or "4096"),
                }
    except Exception:
        pass  # DB not ready or no active row — fall through to env

    # Fallback to env
    provider = settings.LLM_PROVIDER.lower()
    api_key = settings.ANTHROPIC_API_KEY if provider == "anthropic" else settings.OPENAI_API_KEY
    model = settings.LLM_MODEL_ANTHROPIC if provider == "anthropic" else settings.LLM_MODEL_OPENAI
    return {
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "base_url": "",
        "temperature": settings.LLM_TEMPERATURE,
        "max_tokens": settings.LLM_MAX_TOKENS,
    }


async def call_llm(prompt: str, system: str = "") -> str:
    """
    Call the active LLM provider and return raw string response.
    Raises RuntimeError on failure.
    """
    cfg = await _load_active_config()
    provider = cfg["provider"]

    if provider == "anthropic":
        return await _call_anthropic(prompt, system, cfg)
    elif provider in ("openai", "proxyapi"):
        return await _call_openai_compat(prompt, system, cfg)
    else:
        raise RuntimeError(f"Unknown LLM provider: {provider}")


async def _call_anthropic(prompt: str, system: str, cfg: dict) -> str:
    import anthropic
    client = anthropic.Anthropic(api_key=cfg["api_key"])
    response = client.messages.create(
        model=cfg["model"] or settings.LLM_MODEL_ANTHROPIC,
        max_tokens=cfg["max_tokens"],
        temperature=cfg["temperature"],
        system=system or "You are a helpful assistant. Always respond in the requested JSON format.",
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text


async def _call_openai_compat(prompt: str, system: str, cfg: dict) -> str:
    """
    OpenAI-compatible call — works for both OpenAI and ProxyAPI.
    ProxyAPI is an OpenAI-compatible proxy that supports Claude models.
    """
    from openai import OpenAI

    client_kwargs = {"api_key": cfg["api_key"]}
    if cfg.get("base_url"):
        client_kwargs["base_url"] = cfg["base_url"]

    client = OpenAI(**client_kwargs)
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    response = client.chat.completions.create(
        model=cfg["model"] or settings.LLM_MODEL_OPENAI,
        max_tokens=cfg["max_tokens"],
        temperature=cfg["temperature"],
        messages=messages,
    )
    return response.choices[0].message.content


def extract_json(raw: str) -> str:
    """Strip markdown code fences if present and return clean JSON string."""
    raw = raw.strip()
    if raw.startswith("```"):
        lines = raw.split("\n")
        start = 1
        end = len(lines) - 1
        if lines[-1].strip() == "```":
            end = len(lines) - 1
        raw = "\n".join(lines[start:end])
    return raw.strip()
