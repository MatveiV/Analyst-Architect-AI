"""
Seed router — быстрая загрузка демо-данных одним запросом
(перенос удобной практики из MatveiV/Analyst-Guru).
"""
import json
import uuid
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models.document import Document
from app.services import rag_engine

router = APIRouter(prefix="/seed", tags=["seed"])

TESTS_DATA_DIR = Path(__file__).resolve().parents[4] / "tests_data"


@router.post("/documents")
async def seed_documents(db: AsyncSession = Depends(get_db)):
    """Load the 10 example specs from tests_data/specs/specs.jsonl."""
    specs_path = TESTS_DATA_DIR / "specs" / "specs.jsonl"
    if not specs_path.exists():
        return {"loaded": 0, "error": f"File not found: {specs_path}"}

    loaded = 0
    with open(specs_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            spec = json.loads(line)
            doc = Document(
                id=str(uuid.uuid4()),
                created_at=datetime.utcnow(),
                title=spec["title"],
                text=spec["text"],
                doc_type=spec.get("doc_type", "tz"),
            )
            db.add(doc)
            loaded += 1
    await db.commit()
    return {"loaded": loaded}


@router.post("/kb-documents")
async def seed_kb_documents(db: AsyncSession = Depends(get_db)):
    """Load the 5 example knowledge-base articles from tests_data/kb_documents.jsonl."""
    kb_path = TESTS_DATA_DIR / "kb_documents.jsonl"
    if not kb_path.exists():
        return {"loaded": 0, "error": f"File not found: {kb_path}"}

    loaded = 0
    with open(kb_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            item = json.loads(line)
            doc = Document(
                id=str(uuid.uuid4()),
                created_at=datetime.utcnow(),
                title=item["title"],
                text=item["text"],
                doc_type="kb_article",
            )
            db.add(doc)
            await db.flush()
            await rag_engine.index_document(db, doc.id, item["text"])
            loaded += 1
    await db.commit()
    return {"loaded": loaded}


@router.post("/all")
async def seed_all(db: AsyncSession = Depends(get_db)):
    docs = await seed_documents(db)
    kb = await seed_kb_documents(db)
    return {"documents": docs, "kb_documents": kb}
