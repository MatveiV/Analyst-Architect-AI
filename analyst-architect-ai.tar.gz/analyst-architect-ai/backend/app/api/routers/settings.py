"""
Settings router — управление настройками LLM-провайдеров.

GET  /settings/providers          — список всех сохранённых провайдеров (ключи маскируются)
POST /settings/providers          — сохранить / обновить настройки провайдера
POST /settings/providers/activate — переключить активного провайдера
GET  /settings/active             — вернуть активный провайдер для UI
POST /settings/test               — быстрый тест подключения (ping LLM)
"""
import uuid
from datetime import datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database import get_db
from app.models.provider_settings import ProviderSettings
from app.schemas import ProviderSettingsIn, ProviderSettingsOut, ActiveProviderOut

router = APIRouter(prefix="/settings", tags=["settings"])

# Default models per provider
DEFAULT_MODELS = {
    "anthropic": "claude-sonnet-4-20250514",
    "openai": "gpt-4o",
    "proxyapi": "claude-sonnet-4-20250514",
}

DEFAULT_BASE_URLS = {
    "anthropic": "",
    "openai": "",
    "proxyapi": "https://api.proxyapi.ru/anthropic",
}

# ── helpers ───────────────────────────────────────────────────────────────────

def _mask_key(key: str) -> str:
    if not key:
        return ""
    if len(key) <= 8:
        return "*" * len(key)
    return "*" * (len(key) - 4) + key[-4:]


def _row_to_out(row: ProviderSettings) -> ProviderSettingsOut:
    return ProviderSettingsOut(
        id=row.id,
        updated_at=row.updated_at or datetime.utcnow(),
        provider=row.provider,
        api_key_masked=_mask_key(row.api_key or ""),
        model=row.model or DEFAULT_MODELS.get(row.provider, ""),
        base_url=row.base_url or DEFAULT_BASE_URLS.get(row.provider, ""),
        temperature=float(row.temperature or "0.2"),
        max_tokens=int(row.max_tokens or "4096"),
        is_active=(row.is_active == "true"),
    )


async def _get_or_create(db: AsyncSession, provider: str) -> ProviderSettings:
    res = await db.execute(
        select(ProviderSettings).where(ProviderSettings.provider == provider)
    )
    row = res.scalar_one_or_none()
    if not row:
        row = ProviderSettings(
            id=str(uuid.uuid4()),
            provider=provider,
            model=DEFAULT_MODELS.get(provider, ""),
            base_url=DEFAULT_BASE_URLS.get(provider, ""),
            is_active="false",
        )
        db.add(row)
        await db.flush()
    return row


# ── endpoints ─────────────────────────────────────────────────────────────────

@router.get("/providers", response_model=List[ProviderSettingsOut])
async def list_providers(db: AsyncSession = Depends(get_db)):
    """Return all provider configs (api_key masked). Pre-create missing defaults."""
    for p in ("anthropic", "openai", "proxyapi"):
        await _get_or_create(db, p)
    await db.commit()

    res = await db.execute(
        select(ProviderSettings).order_by(ProviderSettings.provider)
    )
    return [_row_to_out(r) for r in res.scalars().all()]


@router.post("/providers", response_model=ProviderSettingsOut)
async def save_provider(body: ProviderSettingsIn, db: AsyncSession = Depends(get_db)):
    """Create or update a provider configuration."""
    row = await _get_or_create(db, body.provider)
    # Only update api_key if a non-empty value is sent (allows keeping existing key)
    if body.api_key:
        row.api_key = body.api_key
    row.model = body.model or DEFAULT_MODELS.get(body.provider, "")
    row.base_url = body.base_url or DEFAULT_BASE_URLS.get(body.provider, "")
    row.temperature = str(body.temperature)
    row.max_tokens = str(body.max_tokens)
    row.updated_at = datetime.utcnow()
    # Don't change is_active here — use /activate endpoint for that
    await db.commit()
    await db.refresh(row)
    return _row_to_out(row)


@router.post("/providers/activate")
async def activate_provider(
    provider: str,
    db: AsyncSession = Depends(get_db),
):
    """Switch active provider. Deactivates all others."""
    if provider not in ("anthropic", "openai", "proxyapi"):
        raise HTTPException(400, f"Unknown provider: {provider}")

    # Ensure all rows exist
    for p in ("anthropic", "openai", "proxyapi"):
        await _get_or_create(db, p)

    # Deactivate all, then activate chosen
    res = await db.execute(select(ProviderSettings))
    for row in res.scalars().all():
        row.is_active = "true" if row.provider == provider else "false"
        row.updated_at = datetime.utcnow()

    await db.commit()

    # Apply to runtime settings
    from app.config import settings as app_settings
    res2 = await db.execute(
        select(ProviderSettings).where(ProviderSettings.provider == provider)
    )
    active_row = res2.scalar_one_or_none()
    if active_row:
        app_settings.LLM_PROVIDER = provider
        if active_row.api_key:
            if provider == "anthropic":
                app_settings.ANTHROPIC_API_KEY = active_row.api_key
            elif provider == "openai":
                app_settings.OPENAI_API_KEY = active_row.api_key
            elif provider == "proxyapi":
                app_settings.PROXYAPI_KEY = active_row.api_key
        if active_row.model:
            if provider == "anthropic":
                app_settings.LLM_MODEL_ANTHROPIC = active_row.model
            elif provider in ("openai", "proxyapi"):
                app_settings.LLM_MODEL_OPENAI = active_row.model
        if active_row.temperature:
            app_settings.LLM_TEMPERATURE = float(active_row.temperature)
        if active_row.max_tokens:
            app_settings.LLM_MAX_TOKENS = int(active_row.max_tokens)

    return {"activated": provider, "status": "ok"}


@router.get("/active", response_model=ActiveProviderOut)
async def get_active(db: AsyncSession = Depends(get_db)):
    """Return current active provider config (for UI status display)."""
    res = await db.execute(
        select(ProviderSettings).where(ProviderSettings.is_active == "true")
    )
    row = res.scalar_one_or_none()
    if not row:
        # Fallback: read from env settings
        from app.config import settings as s
        return ActiveProviderOut(
            provider=s.LLM_PROVIDER,
            model=s.LLM_MODEL_ANTHROPIC if s.LLM_PROVIDER == "anthropic" else s.LLM_MODEL_OPENAI,
            base_url="",
            temperature=s.LLM_TEMPERATURE,
            max_tokens=s.LLM_MAX_TOKENS,
        )
    return ActiveProviderOut(
        provider=row.provider,
        model=row.model or DEFAULT_MODELS.get(row.provider, ""),
        base_url=row.base_url or "",
        temperature=float(row.temperature or "0.2"),
        max_tokens=int(row.max_tokens or "4096"),
    )


@router.post("/test")
async def test_provider(provider: str, db: AsyncSession = Depends(get_db)):
    """Send a minimal ping to the provider to verify API key."""
    res = await db.execute(
        select(ProviderSettings).where(ProviderSettings.provider == provider)
    )
    row = res.scalar_one_or_none()
    if not row or not row.api_key:
        raise HTTPException(400, "No API key configured for this provider")

    try:
        if provider == "anthropic":
            import anthropic
            client = anthropic.Anthropic(api_key=row.api_key)
            resp = client.messages.create(
                model=row.model or DEFAULT_MODELS["anthropic"],
                max_tokens=10,
                messages=[{"role": "user", "content": "Say: OK"}],
            )
            return {"status": "ok", "response": resp.content[0].text[:50]}

        elif provider in ("openai", "proxyapi"):
            from openai import OpenAI
            client = OpenAI(
                api_key=row.api_key,
                base_url=row.base_url or None,
            )
            resp = client.chat.completions.create(
                model=row.model or DEFAULT_MODELS.get(provider, "gpt-4o"),
                max_tokens=10,
                messages=[{"role": "user", "content": "Say: OK"}],
            )
            return {"status": "ok", "response": resp.choices[0].message.content[:50]}

    except Exception as e:
        return {"status": "error", "error": str(e)[:300]}
