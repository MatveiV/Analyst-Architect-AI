import os
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./data/analyst_architect_ai.db")

# Convert sync sqlite URL to async
if DATABASE_URL.startswith("sqlite:///"):
    DATABASE_URL = DATABASE_URL.replace("sqlite:///", "sqlite+aiosqlite:///", 1)
elif DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://", 1)

engine = create_async_engine(
    DATABASE_URL,
    echo=False,
    connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {},
)

AsyncSessionLocal = async_sessionmaker(
    engine, class_=AsyncSession, expire_on_commit=False
)


class Base(DeclarativeBase):
    pass


async def get_db():
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def create_tables():
    from app.models import document, review, snippet, qa_run, audit_run  # noqa
    from app.models import memory_item, decision, risk_catalog, project_lesson  # noqa
    from app.models import architecture_review, api_spec, adr_record, diagram_artifact  # noqa
    from app.models import provider_settings  # noqa
    from app.models import user  # noqa
    from app.models import build_project, task_estimate, economic_estimate, economic_actual  # noqa
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
