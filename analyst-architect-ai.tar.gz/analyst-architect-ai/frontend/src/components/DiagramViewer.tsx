import React, { useEffect, useRef } from 'react';
import { CopyButton } from './ui';

interface Diagram {
  id: string;
  diagram_type: string;
  notation: string;
  source_code: string;
}

const TYPE_LABELS: Record<string, string> = {
  c4_context: 'C4 Context',
  c4_container: 'C4 Container',
  c4_component: 'C4 Component',
  use_case: 'Use Case',
  sequence: 'Sequence',
  class: 'Class Diagram',
  erd: 'ERD',
  flowchart: 'Mermaid Flowchart',
};

function MermaidDiagram({ code }: { code: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    // Mermaid rendering via CDN if available
    const w = window as any;
    if (w.mermaid) {
      try {
        ref.current.innerHTML = code;
        ref.current.removeAttribute('data-processed');
        w.mermaid.init(undefined, ref.current);
      } catch {
        ref.current.innerHTML = `<pre class="code-block text-xs">${code}</pre>`;
      }
    } else {
      ref.current.innerHTML = `<pre class="code-block text-xs">${code}</pre>`;
    }
  }, [code]);
  return <div ref={ref} className="mermaid text-sm" />;
}

export default function DiagramViewer({ diagrams }: { diagrams: Diagram[] }) {
  const [selected, setSelected] = React.useState<Diagram | null>(diagrams[0] || null);

  if (!diagrams.length) {
    return (
      <div className="text-center py-12 text-slate-muted text-sm">
        Диаграммы не сгенерированы. Нажмите «Генерировать диаграммы».
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Diagram tabs */}
      <div className="flex flex-wrap gap-2">
        {diagrams.map(d => (
          <button
            key={d.id}
            onClick={() => setSelected(d)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              selected?.id === d.id
                ? 'bg-accent/20 text-accent border border-accent/30'
                : 'text-slate-muted hover:text-white border border-slate-border hover:border-slate-border/60'
            }`}
          >
            {TYPE_LABELS[d.diagram_type] || d.diagram_type}
            <span className={`ml-1.5 text-xs opacity-60 font-mono ${d.notation === 'mermaid' ? 'text-yellow-400' : 'text-green-400'}`}>
              {d.notation}
            </span>
          </button>
        ))}
      </div>

      {/* Diagram display */}
      {selected && (
        <div className="space-y-3 animate-fade-in">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-white">{TYPE_LABELS[selected.diagram_type]}</p>
            <CopyButton text={selected.source_code} label="Копировать код" />
          </div>

          {selected.notation === 'mermaid' ? (
            <div className="p-4 bg-white rounded-lg">
              <MermaidDiagram code={selected.source_code} />
            </div>
          ) : (
            <pre className="code-block text-xs leading-relaxed max-h-[500px] overflow-auto">
              {selected.source_code}
            </pre>
          )}

          <p className="text-xs text-slate-muted/60">
            {selected.notation === 'plantuml'
              ? 'PlantUML: вставьте код на plantuml.com или в IDE-плагин'
              : 'Mermaid: вставьте код на mermaid.live'}
          </p>
        </div>
      )}
    </div>
  );
}
