"""
conftest.py — sets DATABASE_URL before any app import, creates tables,
provides a session-scoped HTTPX client for integration tests.
"""
import asyncio
import os

# Must be set BEFORE any app module import
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///./data/test_api.db")
os.makedirs("data", exist_ok=True)

import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport

from app.database import create_tables
from app.main import app


# ── Session-wide event loop ───────────────────────────────────────────────────
@pytest.fixture(scope="session")
def event_loop_policy():
    return asyncio.DefaultEventLoopPolicy()


# ── Auto-create DB tables + seed users once before any test runs ──────────────
@pytest.fixture(scope="session", autouse=True)
def create_db_tables():
    """Synchronously bootstrap async table creation and default users."""
    async def _setup():
        await create_tables()
        from app.database import AsyncSessionLocal
        from app.services.auth_service import seed_default_users
        async with AsyncSessionLocal() as db:
            await seed_default_users(db)

    loop = asyncio.new_event_loop()
    loop.run_until_complete(_setup())
    loop.close()


# ── Shared HTTPX client ───────────────────────────────────────────────────────
@pytest_asyncio.fixture(scope="session")
async def client():
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as c:
        yield c
