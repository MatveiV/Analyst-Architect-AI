from __future__ import annotations
from datetime import datetime
from typing import Any, List, Optional
from pydantic import BaseModel, Field, ConfigDict


# ─── Documents ───────────────────────────────────────────────────────────────

class DocumentCreate(BaseModel):
    title: str = Field(min_length=1, max_length=500)
    text: str = Field(min_length=10, max_length=30_000)
    doc_type: str = Field(default="tz")
    project_name: Optional[str] = None


class DocumentOut(BaseModel):
    id: str
    created_at: datetime
    title: str
    text: str
    doc_type: str
    project_name: Optional[str] = None
    model_config = ConfigDict(from_attributes=True)


# ─── Review ──────────────────────────────────────────────────────────────────

class RiskItem(BaseModel):
    severity: str  # low|medium|high
    description: str


class ReviewSchema(BaseModel):
    summary: str = ""
    risks: List[RiskItem] = []
    missing_requirements: List[str] = []
    questions_to_client: List[str] = []
    acceptance_criteria: List[str] = []
    similar_projects: List[str] = []
    lessons_learned: List[str] = []
    related_decisions: List[str] = []
    architecture_risks: List[str] = []
    confidence: str = "medium"
    needs_review: bool = False


class ReviewOut(BaseModel):
    id: str
    created_at: datetime
    document_id: str
    review_json: str
    needs_review: bool
    confidence: str
    error: Optional[str] = None
    model_config = ConfigDict(from_attributes=True)


# ─── Knowledge Base ───────────────────────────────────────────────────────────

class KBQuestionRequest(BaseModel):
    question: str = Field(min_length=5, max_length=2_000)


class SourceItem(BaseModel):
    quote: str
    document_id: Optional[str] = None
    document_title: Optional[str] = None


class AnswerWithSourcesSchema(BaseModel):
    answer: str = ""
    sources: List[SourceItem] = []
    confidence: str = "medium"
    needs_review: bool = False


class QARunOut(BaseModel):
    id: str
    created_at: datetime
    question: str
    answer: str
    sources_json: str
    needs_review: bool
    error: Optional[str] = None
    model_config = ConfigDict(from_attributes=True)


# ─── Audit ───────────────────────────────────────────────────────────────────

class AuditRunOut(BaseModel):
    id: str
    created_at: datetime
    action: str
    input: str
    output: str
    status: str
    error: Optional[str] = None
    duration_ms: int
    model_config = ConfigDict(from_attributes=True)


# ─── Memory ──────────────────────────────────────────────────────────────────

class MemoryStoreRequest(BaseModel):
    memory_type: str = Field(pattern="^(semantic|episodic|decision|risk|requirement)$")
    content: str = Field(min_length=5, max_length=5_000)
    tags: List[str] = []
    project_name: Optional[str] = None


class MemorySearchRequest(BaseModel):
    query: str = Field(min_length=3, max_length=1_000)
    memory_type: Optional[str] = None
    project_name: Optional[str] = None
    limit: int = Field(default=10, ge=1, le=50)


class MemoryItemOut(BaseModel):
    id: str
    created_at: datetime
    memory_type: str
    content: str
    tags: str
    project_name: Optional[str] = None
    relevance_score: Optional[float] = None
    model_config = ConfigDict(from_attributes=True)


# ─── Architecture Recommendation ─────────────────────────────────────────────

class AlternativePattern(BaseModel):
    pattern: str
    pros: List[str] = []
    cons: List[str] = []


class ArchitectureRecommendationSchema(BaseModel):
    recommended_pattern: str = ""
    rationale: str = ""
    alternatives: List[AlternativePattern] = []
    integration_recommendations: List[str] = []
    risks: List[RiskItem] = []
    confidence: str = "medium"
    needs_review: bool = False


class ArchitectureReviewOut(BaseModel):
    id: str
    created_at: datetime
    document_id: str
    recommendation_json: str
    needs_review: bool
    model_config = ConfigDict(from_attributes=True)


# ─── ADR ─────────────────────────────────────────────────────────────────────

class ADRAlternative(BaseModel):
    option: str
    reason_rejected: str


class ADRConsequences(BaseModel):
    positive: List[str] = []
    negative: List[str] = []


class ADRSchema(BaseModel):
    title: str = ""
    status: str = "proposed"
    context: str = ""
    problem: str = ""
    decision: str = ""
    alternatives: List[ADRAlternative] = []
    consequences: ADRConsequences = ADRConsequences()
    confidence: str = "medium"
    needs_review: bool = False


class ADRRecordOut(BaseModel):
    id: str
    created_at: datetime
    document_id: str
    adr_json: str
    model_config = ConfigDict(from_attributes=True)


# ─── API Spec ─────────────────────────────────────────────────────────────────

class APISpecOut(BaseModel):
    id: str
    created_at: datetime
    document_id: str
    openapi_json: str
    openapi_yaml: str
    model_config = ConfigDict(from_attributes=True)


# ─── Diagrams ─────────────────────────────────────────────────────────────────

class DiagramSetSchema(BaseModel):
    c4_context: str = ""
    c4_container: str = ""
    c4_component: str = ""
    use_case: str = ""
    sequence: str = ""
    class_diagram: str = ""
    erd: str = ""
    mermaid_flowchart: str = ""
    confidence: str = "medium"
    needs_review: bool = False


class DiagramArtifactOut(BaseModel):
    id: str
    created_at: datetime
    document_id: str
    diagram_type: str
    notation: str
    source_code: str
    model_config = ConfigDict(from_attributes=True)


# ─── URS / SRS ────────────────────────────────────────────────────────────────

class URSSchema(BaseModel):
    title: str = ""
    objective: str = ""
    stakeholders: List[str] = []
    user_requirements: List[dict] = []
    non_functional_requirements: List[dict] = []
    constraints: List[str] = []
    confidence: str = "medium"
    needs_review: bool = False


class SRSSchema(BaseModel):
    title: str = ""
    introduction: str = ""
    overall_description: str = ""
    functional_requirements: List[dict] = []
    non_functional_requirements: List[dict] = []
    external_interfaces: List[str] = []
    confidence: str = "medium"
    needs_review: bool = False


# ─── Direct AI call ──────────────────────────────────────────────────────────

class DirectReviewRequest(BaseModel):
    text: str = Field(min_length=1, max_length=30_000)


class DirectAnswerRequest(BaseModel):
    question: str = Field(min_length=5, max_length=2_000)
    context: str = Field(default="", max_length=50_000)


# ─── Provider Settings ────────────────────────────────────────────────────────

class ProviderSettingsIn(BaseModel):
    provider: str = Field(pattern="^(anthropic|openai|proxyapi)$")
    api_key: str = Field(default="", max_length=500)
    model: str = Field(default="", max_length=100)
    base_url: str = Field(default="", max_length=500)
    temperature: float = Field(default=0.2, ge=0.0, le=2.0)
    max_tokens: int = Field(default=4096, ge=256, le=32768)
    is_active: bool = False


class ProviderSettingsOut(BaseModel):
    id: str
    updated_at: datetime
    provider: str
    api_key_masked: str   # show only last 4 chars
    model: str
    base_url: str
    temperature: float
    max_tokens: int
    is_active: bool

    model_config = ConfigDict(from_attributes=True)


class ActiveProviderOut(BaseModel):
    provider: str
    model: str
    base_url: str
    temperature: float
    max_tokens: int
