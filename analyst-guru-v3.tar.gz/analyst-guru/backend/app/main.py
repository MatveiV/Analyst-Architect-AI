import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware

from app.database import create_tables
from app.api.routers import documents, reviews, knowledge_base, memory, diagrams, audit
from app.api.routers import settings as settings_router
from app.api.routers import auth as auth_router
from app.api.deps import require_analyst, require_architect

os.makedirs("data", exist_ok=True)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await create_tables()
    # Seed default users on first start
    from app.database import AsyncSessionLocal
    from app.services.auth_service import seed_default_users
    async with AsyncSessionLocal() as db:
        await seed_default_users(db)
    yield


app = FastAPI(
    title="AnalystGuru API",
    description="AI System Analyst Copilot — RAG, ADR, Diagrams, Architecture Recommendations",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
# /auth/* is public (login) or self-protected per-endpoint (register/users = admin only)
app.include_router(auth_router.router)

# Business routers require a valid JWT for any of the three roles
# (admin | analyst | architect)
app.include_router(documents.router, dependencies=[Depends(require_analyst)])
app.include_router(reviews.router, dependencies=[Depends(require_analyst)])
app.include_router(knowledge_base.router, dependencies=[Depends(require_analyst)])
app.include_router(memory.router, dependencies=[Depends(require_analyst)])
app.include_router(diagrams.router, dependencies=[Depends(require_analyst)])
app.include_router(audit.router, dependencies=[Depends(require_analyst)])

# Provider settings: architect or admin only (per Access Matrix)
app.include_router(settings_router.router, dependencies=[Depends(require_architect)])


@app.get("/health")
async def health():
    return {"status": "ok", "service": "AnalystGuru API"}


@app.get("/")
async def root():
    return {
        "name": "AnalystGuru",
        "version": "1.0.0",
        "docs": "/docs",
    }
