import json
import uuid
from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc

from app.database import get_db
from app.models.document import Document
from app.models.review import Review
from app.models.architecture_review import ArchitectureReview
from app.models.adr_record import ADRRecord
from app.models.api_spec import APISpec
from app.models.diagram_artifact import DiagramArtifact
from app.schemas import (
    DocumentCreate, DocumentOut, ReviewOut, ArchitectureReviewOut,
    ADRRecordOut, APISpecOut, DiagramArtifactOut,
)
from app.services import ai_reviewer, rag_engine, architecture_engine
from app.services import adr_generator, doc_generator, diagram_engine, export_service
from app.services.audit_service import with_audit
from app.services.memory_service import get_memory_context

router = APIRouter(prefix="/documents", tags=["documents"])


@router.post("", response_model=DocumentOut)
async def create_document(body: DocumentCreate, db: AsyncSession = Depends(get_db)):
    doc = Document(
        id=str(uuid.uuid4()),
        created_at=datetime.utcnow(),
        title=body.title,
        text=body.text,
        doc_type=body.doc_type,
        project_name=body.project_name,
    )
    db.add(doc)
    await db.commit()
    await db.refresh(doc)

    # Auto-index for RAG if doc_type is kb_article
    if body.doc_type == "kb_article":
        await rag_engine.index_document(db, doc.id, body.text)

    return doc


@router.get("", response_model=List[DocumentOut])
async def list_documents(
    doc_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    q = select(Document).order_by(desc(Document.created_at))
    if doc_type:
        q = q.where(Document.doc_type == doc_type)
    result = await db.execute(q)
    return result.scalars().all()


@router.get("/{doc_id}", response_model=DocumentOut)
async def get_document(doc_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404, "Document not found")
    return doc


@router.post("/{doc_id}/review", response_model=ReviewOut)
async def review_document(doc_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404, "Document not found")

    mem_ctx = await get_memory_context(db, doc.project_name)

    async def _run():
        return await ai_reviewer.run_ai_review(
            doc.text,
            memory_risks=mem_ctx["memory_risks"],
            memory_lessons=mem_ctx["memory_lessons"],
            memory_decisions=mem_ctx["memory_decisions"],
        )

    schema = await with_audit(db, "review", {"document_id": doc_id, "title": doc.title}, _run)

    review = Review(
        id=str(uuid.uuid4()),
        created_at=datetime.utcnow(),
        document_id=doc_id,
        review_json=json.dumps(schema.model_dump(), ensure_ascii=False),
        needs_review=schema.needs_review,
        confidence=schema.confidence,
        error=None,
    )
    db.add(review)
    await db.commit()
    await db.refresh(review)
    return review


@router.post("/{doc_id}/generate-urs")
async def generate_urs(doc_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404, "Document not found")

    async def _run():
        return await doc_generator.generate_urs(doc.text, doc.title)

    schema = await with_audit(db, "generate_urs", {"document_id": doc_id}, _run)
    return schema.model_dump()


@router.post("/{doc_id}/generate-srs")
async def generate_srs(doc_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404, "Document not found")

    async def _run():
        return await doc_generator.generate_srs(doc.text, doc.title)

    schema = await with_audit(db, "generate_srs", {"document_id": doc_id}, _run)
    return schema.model_dump()


@router.post("/{doc_id}/generate-adr", response_model=ADRRecordOut)
async def generate_adr(doc_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404, "Document not found")

    async def _run():
        return await adr_generator.generate_adr(doc.text)

    schema = await with_audit(db, "generate_adr", {"document_id": doc_id}, _run)

    record = ADRRecord(
        id=str(uuid.uuid4()),
        created_at=datetime.utcnow(),
        document_id=doc_id,
        adr_json=json.dumps(schema.model_dump(), ensure_ascii=False),
    )
    db.add(record)
    await db.commit()
    await db.refresh(record)
    return record


@router.post("/{doc_id}/recommend-architecture", response_model=ArchitectureReviewOut)
async def recommend_architecture(doc_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404, "Document not found")

    async def _run():
        return await architecture_engine.recommend_architecture(doc.text)

    schema = await with_audit(db, "recommend_architecture", {"document_id": doc_id}, _run)

    arch_review = ArchitectureReview(
        id=str(uuid.uuid4()),
        created_at=datetime.utcnow(),
        document_id=doc_id,
        recommendation_json=json.dumps(schema.model_dump(), ensure_ascii=False),
        needs_review=schema.needs_review,
    )
    db.add(arch_review)
    await db.commit()
    await db.refresh(arch_review)
    return arch_review


@router.post("/{doc_id}/design-api", response_model=APISpecOut)
async def design_api(doc_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404, "Document not found")

    async def _run_api():
        j, y = await doc_generator.generate_api_spec(doc.text, doc.title)
        # Return a simple container for audit
        class R:
            needs_review = False
            def model_dump(self): return {"json": j[:200]}
        return R()

    await with_audit(db, "design_api", {"document_id": doc_id}, _run_api)
    j, y = await doc_generator.generate_api_spec(doc.text, doc.title)

    spec = APISpec(
        id=str(uuid.uuid4()),
        created_at=datetime.utcnow(),
        document_id=doc_id,
        openapi_json=j,
        openapi_yaml=y,
    )
    db.add(spec)
    await db.commit()
    await db.refresh(spec)
    return spec


@router.post("/{doc_id}/generate-diagrams")
async def generate_diagrams(doc_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404, "Document not found")

    async def _run():
        return await diagram_engine.generate_all_diagrams(doc.text, doc.title)

    schema = await with_audit(db, "generate_diagrams", {"document_id": doc_id}, _run)

    # Store each diagram type
    diagram_map = {
        "c4_context": ("plantuml", schema.c4_context),
        "c4_container": ("plantuml", schema.c4_container),
        "c4_component": ("plantuml", schema.c4_component),
        "use_case": ("plantuml", schema.use_case),
        "sequence": ("plantuml", schema.sequence),
        "class": ("plantuml", schema.class_diagram),
        "erd": ("plantuml", schema.erd),
        "flowchart": ("mermaid", schema.mermaid_flowchart),
    }

    created = []
    for dtype, (notation, code) in diagram_map.items():
        if code:
            artifact = DiagramArtifact(
                id=str(uuid.uuid4()),
                created_at=datetime.utcnow(),
                document_id=doc_id,
                diagram_type=dtype,
                notation=notation,
                source_code=code,
            )
            db.add(artifact)
            created.append({"type": dtype, "notation": notation})

    await db.commit()
    return {"created": created, "needs_review": schema.needs_review}


@router.get("/{doc_id}/export/docx")
async def export_docx(doc_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Document).where(Document.id == doc_id))
    doc = result.scalar_one_or_none()
    if not doc:
        raise HTTPException(404, "Document not found")

    # Get latest review if exists
    rev_result = await db.execute(
        select(Review).where(Review.document_id == doc_id).order_by(desc(Review.created_at)).limit(1)
    )
    review = rev_result.scalar_one_or_none()
    content = json.loads(review.review_json) if review else {"text": doc.text}

    docx_bytes = export_service.export_document_docx(doc.title, content)
    return Response(
        content=docx_bytes,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        headers={"Content-Disposition": f"attachment; filename={doc.title[:30]}.docx"},
    )
