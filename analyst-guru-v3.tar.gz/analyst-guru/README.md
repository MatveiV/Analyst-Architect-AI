# AnalystGuru — AI System Analyst Copilot

> **Enterprise-grade AI инструмент для системного и бизнес-аналитика.**  
> Мультипровайдерный LLM-бэкенд · RAG по базе знаний · ADR-генератор · Архитектурный советник · Диаграммы PlantUML/Mermaid · 5-типовой фреймворк памяти · Полный аудит каждой AI-операции.

---

## Архитектура системы

```
analyst-guru/
├── backend/                    # FastAPI + SQLAlchemy (async)
│   ├── app/
│   │   ├── main.py             # FastAPI app + lifespan
│   │   ├── config.py           # Настройки из env
│   │   ├── database.py         # Async SQLAlchemy engine + get_db
│   │   ├── models/             # 13 SQLAlchemy ORM-моделей
│   │   ├── schemas/            # Pydantic v2 схемы (strict JSON)
│   │   ├── services/           # Бизнес-логика (без зависимостей от FastAPI)
│   │   │   ├── llm_client.py       # Unified LLM: Anthropic / OpenAI
│   │   │   ├── ai_reviewer.py      # AI-рецензент ТЗ
│   │   │   ├── rag_engine.py       # Гибридный RAG (keyword + semantic)
│   │   │   ├── memory_service.py   # 5-типовой фреймворк памяти
│   │   │   ├── architecture_engine.py  # Архитектурные рекомендации
│   │   │   ├── adr_generator.py    # ADR-генератор
│   │   │   ├── diagram_engine.py   # PlantUML + Mermaid диаграммы
│   │   │   ├── doc_generator.py    # URS / SRS / OpenAPI spec
│   │   │   ├── export_service.py   # JSON / CSV / DOCX экспорт
│   │   │   └── audit_service.py    # Аудит всех AI-операций
│   │   └── api/routers/        # 6 FastAPI роутеров
│   └── tests/                  # 39 pytest тестов (unit + integration + RBAC)
├── frontend/                   # React 18 + TypeScript + Tailwind CSS
│   └── src/
│       ├── pages/              # 7 страниц (Documents, Reviews, KB, Studio, Memory, Audit, Detail)
│       ├── components/         # Layout, ReviewCard, DiagramViewer, UI-kit
│       └── api/                # Axios клиент для всех эндпоинтов
├── tests_data/
│   ├── specs/specs.jsonl       # 10 тестовых ТЗ (6 нормальных + 4 edge-case)
│   ├── kb_documents.jsonl      # 5 KB-документов с реалистичным контентом
│   └── kb_questions.jsonl      # 10 вопросов (7 с ответами + 3 без данных)
├── docker-compose.yml
└── .env.example
```

---

## Быстрый старт

### 1. Клонировать и настроить

```bash
git clone <repo-url>
cd analyst-guru
cp .env.example .env
# Отредактируй .env: выбери провайдер, вставь API ключ
```

### 2. Запуск через Docker Compose

```bash
docker-compose up --build
# Backend: http://localhost:8000
# Frontend: http://localhost:3000
# Swagger UI: http://localhost:8000/docs
```

### 3. Локальный запуск (без Docker)

**Backend:**
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

**Frontend:**
```bash
cd frontend
npm install
REACT_APP_API_URL=http://localhost:8000 npm start
```

---

## Авторизация и роли

Доступ к приложению требует **входа по логину и паролю** — без авторизации API возвращает `401`.

### Роли

| Роль | Логин по умолчанию | Пароль | Доступ |
|------|--------------------|--------|--------|
| Администратор | `admin` | `admin123` | Всё + управление пользователями |
| Архитектор | `architect` | `architect123` | Всё бизнес-функции + настройки AI |
| Аналитик | `analyst` | `analyst123` | Документы, рецензии, KB, память, аудит |

> ⚠️ Смените пароли по умолчанию перед продакшн-деплоем: `POST /auth/users/{id}/reset-password`

### Быстрая проверка

```bash
# Получить токен
TOKEN=$(curl -s -X POST http://localhost:8000/auth/login \
  -d "username=analyst&password=analyst123" | python3 -c "import sys,json;print(json.load(sys.stdin)['access_token'])")

# Использовать токен
curl -H "Authorization: Bearer $TOKEN" http://localhost:8000/documents

# Без токена — 401
curl -i http://localhost:8000/documents
```

Подробнее: [docs/admin-guide-ru.md](docs/admin-guide-ru.md#3-ролевая-модель-и-авторизация)

## Конфигурация (.env)

| Переменная | Описание | По умолчанию |
|-----------|----------|-------------|
| `LLM_PROVIDER` | Провайдер: `anthropic` или `openai` | `anthropic` |
| `ANTHROPIC_API_KEY` | Ключ Anthropic Claude | — |
| `OPENAI_API_KEY` | Ключ OpenAI GPT | — |
| `DATABASE_URL` | SQLite или PostgreSQL URL | `sqlite:///./data/analyst_guru.db` |
| `MAX_DOCUMENT_LENGTH` | Макс. длина документа (символы) | `30000` |
| `RAG_TOP_K` | Топ-K фрагментов для RAG | `5` |
| `LLM_TEMPERATURE` | Температура LLM | `0.2` |
| `LLM_MAX_TOKENS` | Макс. токенов ответа | `4096` |

---

## API эндпоинты

### Документы
| Метод | Путь | Описание |
|-------|------|----------|
| `POST` | `/documents` | Создать документ |
| `GET` | `/documents` | Список документов |
| `GET` | `/documents/{id}` | Получить документ |
| `POST` | `/documents/{id}/review` | AI-рецензия |
| `POST` | `/documents/{id}/generate-urs` | Сгенерировать URS |
| `POST` | `/documents/{id}/generate-srs` | Сгенерировать SRS |
| `POST` | `/documents/{id}/generate-adr` | Сгенерировать ADR |
| `POST` | `/documents/{id}/recommend-architecture` | Рекомендовать архитектуру |
| `POST` | `/documents/{id}/design-api` | Сгенерировать OpenAPI spec |
| `POST` | `/documents/{id}/generate-diagrams` | Сгенерировать все диаграммы |
| `GET` | `/documents/{id}/export/docx` | Экспорт в DOCX |

### База знаний (RAG)
| Метод | Путь | Описание |
|-------|------|----------|
| `POST` | `/kb/documents` | Добавить KB-документ + индексировать |
| `GET` | `/kb/documents` | Список KB-документов |
| `POST` | `/kb/ask` | Задать вопрос (RAG-поиск + LLM) |
| `GET` | `/kb/history` | История Q&A |
| `POST` | `/kb/reindex` | Переиндексировать все документы |

### Фреймворк памяти
| Метод | Путь | Описание |
|-------|------|----------|
| `POST` | `/memory/store` | Сохранить элемент памяти |
| `POST` | `/memory/search` | Поиск по памяти (keyword) |
| `GET` | `/memory/recent` | Последние элементы памяти |
| `POST` | `/memory/consolidate` | Дедупликация памяти |

### Диаграммы
| Метод | Путь | Описание |
|-------|------|----------|
| `GET` | `/diagrams/document/{doc_id}` | Диаграммы документа |
| `POST` | `/diagrams/generate-c4` | C4 диаграммы (Context/Container/Component) |
| `POST` | `/diagrams/generate-uml` | UML диаграммы |
| `POST` | `/diagrams/generate-erd` | ERD диаграмма |

### Аудит
| Метод | Путь | Описание |
|-------|------|----------|
| `GET` | `/audit` | Список аудит-записей (фильтры: action, status) |
| `GET` | `/audit/stats` | Статистика операций |

---

## Ключевые технические решения

### AI Reviewer — защита от некачественного ввода
- `_is_too_vague()` — детект документов < 8 слов → `needs_review=True` без LLM-вызова
- `_detect_contradiction()` — эвристики на противоречия в требованиях
- `safe_fallback_review()` — безопасный fallback при ошибке JSON/LLM с корректными вопросами
- Всегда: `confidence="low"` и `needs_review=True` при fallback

### RAG Engine — гибридный поиск
- Splitting: параграфы → предложения → слова (max 500 символов)
- Скоринг: `0.4 × keyword_score + 0.6 × semantic_similarity`
- Эмбеддинги: `sentence-transformers/all-MiniLM-L6-v2` (lazy-load)
- Правило: нет источников → `needs_review=True`, ответ "Данных недостаточно..."

### Memory Framework — 5 типов памяти
| Тип | Назначение |
|-----|-----------|
| `semantic` | Концепции, правила, стандарты |
| `episodic` | Уроки проектов, ретроспективы |
| `decision` | Архитектурные решения |
| `risk` | Типовые риски проектов |
| `requirement` | Извлечённые требования |

### Audit Service — обёртка `with_audit()`
Каждый AI-вызов оборачивается в `with_audit()`, который:
- Записывает action, input, output, status, duration_ms
- Выставляет status=`needs_review` если результат содержит `needs_review=True`
- Выставляет status=`error` при исключении

---

## Тестирование

```bash
cd backend

# Все тесты (24 штуки)
python -m pytest tests/ -v --asyncio-mode=auto

# Только unit-тесты (без HTTP)
python -m pytest tests/ -v -k "not asyncio"

# Только API-тесты
python -m pytest tests/ -v -k "test_health or test_create or test_list or test_add or test_audit or test_memory"
```

### Покрытие
| Категория | Тестов | Статус |
|-----------|--------|--------|
| AI Reviewer (unit) | 5 | ✅ |
| RAG Engine (unit) | 5 | ✅ |
| API: /health, /documents, /kb, /memory, /audit | 11 | ✅ |
| needs_review logic | 3 | ✅ |
| **RBAC & Auth** | 15 | ✅ |
| **Итого** | **39** | ✅ |

---

## Загрузка тестовых данных

```bash
# Загрузить KB-документы через API
python - << 'EOF'
import httpx, json

BASE = "http://localhost:8000"

# Загружаем KB-документы
with open("tests_data/kb_documents.jsonl") as f:
    for line in f:
        doc = json.loads(line)
        r = httpx.post(f"{BASE}/kb/documents", json={
            "title": doc["title"],
            "text": doc["text"],
            "doc_type": "kb_article"
        })
        print(f"Added: {doc['title'][:40]} → {r.status_code}")

# Загружаем тестовые ТЗ как документы
with open("tests_data/specs/specs.jsonl") as f:
    for line in f:
        spec = json.loads(line)
        r = httpx.post(f"{BASE}/documents", json={
            "title": spec["title"],
            "text": spec["text"],
            "doc_type": "tz"
        })
        print(f"Added TZ: {spec['title'][:40]} → {r.status_code}")
EOF
```

---

## Frontend — страницы

| Страница | Путь | Описание |
|---------|------|----------|
| 📄 Документы | `/` | Список + создание + быстрая рецензия |
| 🔍 Документ | `/documents/:id` | Детальная страница со всеми генераторами |
| 🔍 Рецензии | `/reviews` | История рецензий с фильтром needs_review |
| 🧠 База знаний | `/kb` | Q&A + управление KB-документами + история |
| 🏛 Арх. студия | `/studio` | Архитектура + ADR + API + Диаграммы + URS/SRS |
| 💾 Память | `/memory` | Просмотр + поиск + добавление элементов памяти |
| 📋 Аудит | `/audit` | Таблица операций + статистика + детали |

---

## Безопасность и качество кода

- **Pydantic v2** — строгая валидация всех входных данных
- **Max document length** — 30 000 символов (настраивается)
- **Structured JSON output** — все LLM-ответы парсируются через Pydantic, fallback при ошибке
- **No prompt injection** — входной текст не выполняется, только анализируется
- **CORS** — настроен (в prod ограничить allowed_origins)
- **Audit trail** — каждый AI-вызов залогирован с input/output

---

## Расширение системы

### Добавить нового LLM-провайдера
1. Добавить функцию `_call_<provider>()` в `app/services/llm_client.py`
2. Добавить ветку в `call_llm()`
3. Добавить `LLM_PROVIDER=<provider>` в `.env`

### Добавить новый тип диаграммы
1. Добавить поле в `DiagramSetSchema`
2. Расширить промпт в `diagram_engine.py`
3. Добавить mapping в `documents.py` router

### Переключиться на PostgreSQL
```env
DATABASE_URL=postgresql://user:password@localhost:5432/analyst_guru
```
Добавить `asyncpg` в requirements.txt — остальное без изменений.

---

## Документация проекта

| Документ | Описание |
|---------|----------|
| [docs/user-guide-ru.md](docs/user-guide-ru.md) | Руководство пользователя (RU) с C4/UML диаграммами |
| [docs/user-guide-en.md](docs/user-guide-en.md) | User Guide (EN) with C4/UML diagrams |
| [docs/admin-guide-ru.md](docs/admin-guide-ru.md) | Руководство администратора (RU): деплой, роли, безопасность |
| [docs/admin-guide-en.md](docs/admin-guide-en.md) | Administrator Guide (EN) |
| [docs/graduation-report.md](docs/graduation-report.md) | Отчёт по выпускному проекту (ценность, мини-экономика, риски) |
| [docs/defense-script.md](docs/defense-script.md) | Сценарий защиты проекта (5–7 минут) |

## Лицензия

MIT — свободное использование в личных и коммерческих проектах.

---

*AnalystGuru v1.0.0 — Собрано с ❤️ как senior-grade vibe-coding проект*
